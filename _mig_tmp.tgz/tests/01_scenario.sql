-- =====================================================================
-- Scénario de vérification de bout en bout
-- Lancé par ./supabase/tests/run.sh
--
-- Couvre : profil, enregistrement de partie, attribution des badges,
-- défi à deux joueurs avec questions identiques, classements par
-- période et par portée, et cinq tentatives de contournement qui
-- doivent TOUTES échouer (score gonflé, double participation,
-- changement de classe, auto-attribution de badge, lecture des
-- données d'un autre élève).
--
-- Toute ligne contenant « ECHEC » signale une régression de sécurité.
-- =====================================================================
\set ALICE '11111111-1111-1111-1111-111111111111'
\set BOB   '22222222-2222-2222-2222-222222222222'
\set PROF  '33333333-3333-3333-3333-333333333333'
\set PROF2 '44444444-4444-4444-4444-444444444444'

\echo '=== 1. Alice consulte son profil ==='
set role authenticated;
select set_config('request.jwt.claim.sub', :'ALICE', false);
select jsonb_pretty(jsonb_build_object(
  'prenom',  mon_profil()->'profil'->>'prenom',
  'records', mon_profil()->'records',
  'nb_faits_maitrise', (select count(*) from jsonb_object_keys(mon_profil()->'maitrise'))
));

\echo '=== 2. Alice enregistre une partie (série de 30) ==='
select enregistrer_session(
  p_mode => 'flawless', p_tables => '{7,8,9}'::smallint[],
  p_nb_questions => 30, p_score => 30, p_duree_s => 62.5,
  p_serie_max => 30, p_sans_faute_max => 30,
  p_maitrise => '{"7_8":3,"8_9":3,"7_9":2}'::jsonb
) as resultat;

\echo '=== 3. Tentative de tricherie : score > nb de questions ==='
do $$ begin
  perform enregistrer_session(p_mode=>'sprint', p_tables=>'{2}'::smallint[],
                              p_nb_questions=>10, p_score=>999);
  raise notice 'ECHEC : la triche est passée !';
exception when others then
  raise notice 'OK : refusé (%)', sqlerrm;
end $$;

\echo '=== 4. Alice crée un défi Sprint ==='
reset role; set role authenticated;
select set_config('request.jwt.claim.sub', :'ALICE', false);
select creer_defi('sprint', '{6,7,8}'::smallint[], 20) as defi \gset alice_
\echo '=== 5. Bob rejoint avec le code ==='
select set_config('request.jwt.claim.sub', :'BOB', false);
select (rejoindre_defi((:'alice_defi'::jsonb)->>'code')->>'ok')::boolean as bob_peut_jouer,
       jsonb_array_length(rejoindre_defi((:'alice_defi'::jsonb)->>'code')->'questions') as nb_questions;

\echo '=== 6. Code inexistant ==='
select rejoindre_defi('ZZZZZ')->>'raison' as raison, rejoindre_defi('ZZZZZ')->>'message' as message;

\echo '=== 7. Les deux terminent ==='
select terminer_defi((:'alice_defi'::jsonb->>'defi_id')::uuid, 18, 74.5, 2) as bob_ok;
select set_config('request.jwt.claim.sub', :'ALICE', false);
select terminer_defi((:'alice_defi'::jsonb->>'defi_id')::uuid, 20, 81.0, 0) as alice_ok;

\echo '=== 8. Alice retente (doit être refusé) ==='
do $$ declare v_id uuid; begin
  select id into v_id from defis order by cree_le desc limit 1;
  perform terminer_defi(v_id, 20, 40.0, 0);
  raise notice 'ECHEC : double participation acceptée !';
exception when others then
  raise notice 'OK : refusé (%)', sqlerrm;
end $$;

\echo '=== 9. Classement du défi (tri sprint = temps + 3s/erreur) ==='
select * from classement_defi((:'alice_defi'::jsonb->>'defi_id')::uuid);

\echo '=== 10. Avancement ==='
select avancement_defi((:'alice_defi'::jsonb->>'defi_id')::uuid);

\echo '=== 11. Classement Progression — semaine, collège ==='
select rang, nom_affiche, classe, points, est_moi
  from classement_progression('semaine', 'college', 'decouverte', 8);

\echo '=== 12. Classement Records — série, tout, collège ==='
select rang, nom_affiche, classe, valeur, est_moi
  from classement_records('serie', 'tout', 'college', 'decouverte', 5);

\echo '=== 13. Classement Records — sprint (plus petit temps gagne) ==='
select rang, nom_affiche, valeur from classement_records('sprint', 'tout', 'college', 'decouverte', 5);

\echo '=== 14. Ma classe uniquement ==='
select rang, nom_affiche, classe from classement_progression('semaine', 'classe', 'decouverte', 8);

\echo '=== 15. Aucun email ne fuit dans les classements ==='
select count(*) as colonnes_sensibles
  from information_schema.columns
 where table_schema='public'
   and column_name in ('email')
   and table_name in ('classement_defi','classement_records','classement_progression');

\echo '=== 16. Bob ne voit PAS les sessions d Alice (RLS) ==='
select set_config('request.jwt.claim.sub', :'BOB', false);
select count(*) as sessions_visibles_par_bob from sessions_jeu;
select count(*) as eleves_visibles_par_bob from eleves;

\echo '=== 17. Bob tente de changer sa classe (doit être ignoré) ==='
update eleves set classe='6Z' where id = eleve_courant();
select prenom, classe from eleves where id = eleve_courant();

\echo '=== 18. Bob tente de s attribuer un badge ==='
do $$ begin
  insert into badges (eleve_id, badge_id) values (eleve_courant(), 'streak_100');
  raise notice 'ECHEC : badge auto-attribué !';
exception when others then
  raise notice 'OK : refusé (%)', sqlerrm;
end $$;

\echo '=== 19. Pondération : une table facile rapporte moins ==='
reset role; set role authenticated;
select set_config('request.jwt.claim.sub', :'ALICE', false);
select round(poids_moyen('{2,5}'::smallint[]),2)  as tables_faciles,
       round(poids_moyen('{7,8}'::smallint[]),2)  as tables_dures,
       round(poids_moyen('{13,17}'::smallint[]),2) as tables_expertes;
select palier_tables('{2,5,10}'::smallint[]) as p1,
       palier_tables('{11,12}'::smallint[])  as p2,
       palier_tables('{17,19}'::smallint[])  as p3;

\echo '=== 20. Alice (plafond 10) tente les tables de 17 ==='
do $$ begin
  perform enregistrer_session(p_mode=>'libre', p_tables=>'{17}'::smallint[],
                              p_nb_questions=>10, p_score=>10);
  raise notice 'ECHEC : tables au-dessus du plafond acceptées !';
exception when others then
  raise notice 'OK : refusé (%)', sqlerrm;
end $$;

\echo '=== 21. Deux parties de même score, difficulté différente ==='
select (enregistrer_session('libre','{2,5}'::smallint[],20,20)->>'points')::int as pts_faciles;
select (enregistrer_session('libre','{7,9}'::smallint[],20,20)->>'points')::int as pts_dures;

\echo '=== 22. La Montée débloque les tables suivantes ==='
select (enregistrer_session('climb','{2,3,4,5,6,7,8,9,10}'::smallint[],45,41,
        p_plus_haute_table=>10::smallint)->>'plafond_tables')::int as nouveau_plafond;

\echo '=== 23. Tables faibles suggérées ==='
select mes_tables_faibles(4) as a_reviser;

\echo '=== 24. Vue enseignant : maîtrise de la classe 6A ==='
select set_config('request.jwt.claim.sub', :'PROF', false);
select table_n, eleves_verts, eleves_total, taux_maitrise
  from maitrise_classe('6A') limit 6;

\echo '=== 25. Portee NIVEAU : tous les 6e du college ==='
reset role; set role authenticated;
select set_config('request.jwt.claim.sub', :'ALICE', false);
select niveau_scolaire('6A') as n1, niveau_scolaire('5A') as n2, niveau_scolaire('3B') as n3;
select rang, nom_affiche, classe from classement_progression('semaine','niveau','decouverte',10);

\echo '=== 26. Classement des classes (moyenne par eleve) ==='
select rang, classe, eleves_actifs, eleves_total, points_moyens, est_ma_classe
  from classement_classes('semaine');

\echo '=== 27. Classement des classes, 6e uniquement ==='
select rang, classe, points_moyens from classement_classes('semaine','6');

\echo '=== 28. Le prof voit bien sa classe ==='
select set_config('request.jwt.claim.sub', :'PROF', false);
select count(*) as eleves_visibles_par_prof from eleves;
select count(*) as sessions_visibles_par_prof from sessions_jeu;

reset role;

\echo '=== 32. Tableau d honneur : palier tous, college entier ==='
reset role; set role authenticated;
select set_config('request.jwt.claim.sub', :'ALICE', false);
select rang, nom_affiche, classe, points
  from classement_progression('tout','college','tous',10);

\echo '=== 33. Comparaison : palier decouverte seul vs tous ==='
select 'decouverte' as portee, count(*) as nb from classement_records('serie','tout','college','decouverte',50)
union all
select 'tous',              count(*)     from classement_records('serie','tout','college','tous',50);
reset role;

\echo '=== 34. ADMIN : import de rentree ==='
reset role; set role authenticated;
select set_config('request.jwt.claim.sub', :'PROF', false);
select jsonb_pretty(importer_eleves('[
  {"email":"nouveau.eleve@demo.saintho.fr","nom":"Nouveau","prenom":"Eleve","classe":"6A"},
  {"email":"alice.dupont@demo.saintho.fr","nom":"Dupont","prenom":"Alice","classe":"6A"},
  {"email":"PAS-UN-EMAIL","nom":"X","prenom":"Y","classe":"6A"}
]'::jsonb) - 'actifs_absents_du_fichier');

\echo '=== 35. ADMIN : ajout a l unite ==='
select ajouter_eleve('arrivee.novembre@demo.saintho.fr','Tardif','Marie','6B')->>'message' as resultat;

\echo '=== 36. ADMIN : doublon refuse ==='
select ajouter_eleve('arrivee.novembre@demo.saintho.fr','Tardif','Marie','6B')->>'raison' as resultat;

\echo '=== 37. ADMIN : plafond de toute une classe ==='
select definir_plafond_classe('6A', 12::smallint)->>'message' as resultat;

\echo '=== 38. ADMIN : correction d email interdite apres connexion ==='
do $$ declare v uuid; begin
  select id into v from eleves where email='alice.dupont@demo.saintho.fr';
  perform modifier_eleve(v, p_email=>'autre@demo.saintho.fr');
  raise notice 'ECHEC : email change alors que l eleve s est connecte !';
exception when others then raise notice 'OK : refuse (%)', sqlerrm; end $$;

\echo '=== 39. ADMIN : desactivation conserve les resultats ==='
do $$ declare v uuid; n int; begin
  select id into v from eleves where email='hugo.lambert@demo.saintho.fr';
  perform desactiver_eleve(v, 'demenagement');
  select count(*) into n from sessions_jeu where eleve_id = v;
  raise notice 'OK : desactive, % sessions conservees', n;
end $$;

\echo '=== 40. Eleves jamais connectes ==='
select classe, count(*) as jamais_connectes from eleves_sans_connexion() group by classe order by classe;

\echo '=== 41. Journal : qui a fait quoi ==='
select acteur_email, action, coalesce(cible,'-') as cible from journal_admin order by id;

\echo '=== 42. Un ELEVE ne peut pas administrer ==='
select set_config('request.jwt.claim.sub', :'BOB', false);
do $$ begin
  perform ajouter_eleve('pirate@demo.saintho.fr','P','P','6A');
  raise notice 'ECHEC : un eleve a pu ajouter un compte !';
exception when others then raise notice 'OK : refuse (%)', sqlerrm; end $$;
do $$ begin
  perform importer_eleves('[]'::jsonb);
  raise notice 'ECHEC : un eleve a pu importer !';
exception when others then raise notice 'OK : refuse (%)', sqlerrm; end $$;
reset role;

\echo '=== 43. PROFS : creation de comptes ==='
reset role; set role authenticated;
select set_config('request.jwt.claim.sub', :'PROF', false);
select creer_prof('cyrille@demo.saintho.fr','Cyrille Moreau','admin','{6A,6B}')->>'message' as r1;
select creer_prof('nouveau.prof@demo.saintho.fr','M. Nouveau','prof')->>'message' as r2;

\echo '=== 44. PROFS : liste ==='
select nom, role, actif, connecte from liste_profs();

\echo '=== 45. GARDE-FOU : on ne peut pas retirer le dernier admin ==='
do $$ declare v uuid; begin
  -- on retrograde d abord Cyrille pour n avoir qu un seul admin
  select id into v from profs where email='cyrille@demo.saintho.fr';
  perform modifier_prof(v, p_role=>'prof');
  select id into v from profs where email='prof.demo@demo.saintho.fr';
  perform modifier_prof(v, p_role=>'prof');
  raise notice 'ECHEC : le dernier admin a pu etre retrograde !';
exception when others then raise notice 'OK : refuse (%)', sqlerrm; end $$;

\echo '=== 46. Un prof NON admin voit toutes les classes ==='
select set_config('request.jwt.claim.sub', :'PROF2', false);
select classe, eleves_actifs, est_favorite from liste_classes();

\echo '=== 47. Un prof NON admin gere les eleves de TOUTE classe ==='
select ajouter_eleve('test.crossclass@demo.saintho.fr','Test','Cross','5A')->>'ok' as autorise;

\echo '=== 48. Mais il ne peut PAS creer de compte prof ==='
do $$ begin
  perform creer_prof('pirate@demo.saintho.fr','P','admin');
  raise notice 'ECHEC : un prof non admin a cree un compte !';
exception when others then raise notice 'OK : refuse (%)', sqlerrm; end $$;

\echo '=== 49. Ses classes favorites ==='
select definir_mes_classes('{5A}')->>'ok' as ok;
select classe, est_favorite from liste_classes() where est_favorite;
reset role;

\echo '=== 50. QUI SUIS-JE : un eleve ==='
reset role; set role authenticated;
select set_config('request.jwt.claim.sub', :'ALICE', false);
select qui_suis_je()->>'type' as type, qui_suis_je()->'profil'->>'prenom' as prenom;

\echo '=== 51. QUI SUIS-JE : un prof admin ==='
select set_config('request.jwt.claim.sub', :'PROF', false);
select qui_suis_je()->>'type' as type, qui_suis_je()->>'admin' as admin, qui_suis_je()->'profil'->>'nom' as nom;

\echo '=== 52. QUI SUIS-JE : compte inconnu ==='
select set_config('request.jwt.claim.sub', '99999999-9999-9999-9999-999999999999', false);
select qui_suis_je()->>'type' as type, qui_suis_je()->>'message' as message;

\echo '=== 53. Les profs jouent ==='
select set_config('request.jwt.claim.sub', :'PROF', false);
select (enregistrer_session_prof('countdown','{7,8,9}'::smallint[],45,42,120.0,15,15)->>'points')::int as pts_prof1;
select set_config('request.jwt.claim.sub', :'PROF2', false);
select (enregistrer_session_prof('countdown','{13,17}'::smallint[],30,28,120.0,12,12)->>'points')::int as pts_prof2;

\echo '=== 54. Classement de la salle des profs (nom complet) ==='
select rang, nom, valeur, parties, est_moi from classement_profs('points');

\echo '=== 55. Un ELEVE ne voit RIEN du classement des profs ==='
select set_config('request.jwt.claim.sub', :'ALICE', false);
select count(*) as lignes_vues_par_un_eleve from classement_profs('points');
select count(*) as sessions_profs_lues_par_un_eleve from sessions_profs;

\echo '=== 56. Un ELEVE ne peut pas enregistrer une partie de prof ==='
do $$ begin
  perform enregistrer_session_prof('libre','{2}'::smallint[],10,10);
  raise notice 'ECHEC : un eleve a enregistre une partie de prof !';
exception when others then raise notice 'OK : refuse (%)', sqlerrm; end $$;

\echo '=== 57. Les profs n apparaissent PAS dans les classements eleves ==='
select count(*) as profs_dans_classement_eleves
  from classement_progression('tout','college','tous',50)
 where nom_affiche like '%Calcul%' or nom_affiche like '%Demonstration%';

-- =====================================================================
-- 58-60. La Montee des tables ne se gagne qu'en Montee
-- Regression : les badges climb_* etaient accordes des que la plus
-- grande table COCHEE atteignait le seuil, quel que soit le mode.
-- =====================================================================
-- Remise a zero des badges de montee : impossible pour un eleve
-- (aucun droit de suppression sur `badges`), on passe par le proprietaire.
reset role;
delete from badges where badge_id like 'climb_%'
  and eleve_id = (select id from eleves where email = 'alice.dupont@demo.saintho.fr');
set role authenticated;
select set_config('request.jwt.claim.sub','11111111-1111-1111-1111-111111111111', false);

\echo '=== 58. Entrainement libre en cochant la table 10 : AUCUN badge de montee ==='
select enregistrer_session('libre','{9,10}'::smallint[],10,10,
       '[]'::jsonb,30,10,10,10::smallint,'{}'::jsonb,null) -> 'nouveaux_badges' as doit_etre_vide;
select case when count(*) = 0 then 'OK : aucun badge de montee'
            else 'ECHEC : badge de montee accorde en mode libre' end as verdict
  from badges where eleve_id = eleve_courant() and badge_id like 'climb_%';
select case when plus_haute_table is null then 'OK : colonne non renseignee hors Montee'
            else 'ECHEC : la table cochee a ete enregistree comme atteinte' end as verdict
  from sessions_jeu where eleve_id = eleve_courant() order by cree_le desc limit 1;

\echo '=== 59. Vraie Montee jusqu a la table 10 : le badge est accorde ==='
select enregistrer_session('climb','{2,3,4,5,6,7,8,9,10}'::smallint[],30,30,
       '[]'::jsonb,90,30,30,10::smallint,'{}'::jsonb,null) -> 'nouveaux_badges' as doit_contenir_climb_10;
select case when count(*) = 1 then 'OK : badge climb_10 accorde'
            else 'ECHEC : badge de montee manquant' end as verdict
  from badges where eleve_id = eleve_courant() and badge_id = 'climb_10';

\echo '=== 60. Tables au-dessus du plafond : refus avec un message lisible ==='
do $$ begin
  perform enregistrer_session('libre','{14}'::smallint[],5,5);
  raise notice 'ECHEC : partie acceptee sur une table verrouillee';
exception when others then raise notice 'OK : refuse (%)', sqlerrm; end $$;

-- =====================================================================
-- 61-63. Premier coup / rattrapage : chercher doit toujours payer
-- Regression a empecher : si un rattrapage ne vaut rien, abandonner
-- devient la meilleure strategie sous chrono.
-- =====================================================================
\echo '=== 61. 20/20 du premier coup > 20/20 avec 8 rattrapages > 12/20 sans rattrapage ==='
with a as (select (enregistrer_session('libre','{7,8}'::smallint[],20,20,
                    '[]'::jsonb,60,20,20,null,'{}'::jsonb,null,20)->>'points')::int as p),
     b as (select (enregistrer_session('libre','{7,8}'::smallint[],20,20,
                    '[]'::jsonb,60,20,20,null,'{}'::jsonb,null,12)->>'points')::int as p),
     c as (select (enregistrer_session('libre','{7,8}'::smallint[],20,12,
                    '[]'::jsonb,60,12,12,null,'{}'::jsonb,null,12)->>'points')::int as p)
select a.p as tout_premier_coup, b.p as avec_rattrapages, c.p as a_abandonne,
       case when a.p > b.p and b.p > c.p
            then 'OK : chercher paye plus qu abandonner'
            else 'ECHEC : mauvaise incitation' end as verdict
  from a, b, c;

\echo '=== 62. Ancien client hors ligne : parametre absent, aucune penalite ==='
select case when (enregistrer_session('libre','{7,8}'::smallint[],10,10)->>'premier_essai')::int = 10
            then 'OK : traite comme premier coup'
            else 'ECHEC : ancienne partie penalisee' end as verdict;

\echo '=== 63. Un premier essai superieur au score est refuse ==='
do $$ begin
  perform enregistrer_session('libre','{7,8}'::smallint[],10,5,
          '[]'::jsonb,10,0,0,null,'{}'::jsonb,null,9);
  raise notice 'ECHEC : premier_essai > score accepte';
exception when others then raise notice 'OK : refuse (%)', sqlerrm; end $$;

reset role;
